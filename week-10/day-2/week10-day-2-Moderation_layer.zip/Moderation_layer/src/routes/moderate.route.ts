import { Router, Request, Response, NextFunction } from 'express';
import { DecisionEngine } from '../engine/decision.engine';

const router = Router();
const engine = new DecisionEngine();

router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const text = typeof req.body?.text === 'string' ? req.body.text : '';

    if (!text) {
      res.status(400).json({ status: 'error', message: '`text` field is required' });
      return;
    }

    const response = engine.moderate(text);
    response.metadata.processingTimeMs = Date.now() - start;

    res.status(response.action === 'BLOCK' ? 422 : 200).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
