import { Router } from 'express';
import { FileDetector } from '../../detectors/file.detector';

const router = Router();
const detector = new FileDetector();

router.post('/', (req, res) => {
  const fileName = typeof req.body?.fileName === 'string' ? req.body.fileName : 'unknown.txt';
  const mimeType = typeof req.body?.mimeType === 'string' ? req.body.mimeType : 'text/plain';
  const sizeBytes = typeof req.body?.sizeBytes === 'number' ? req.body.sizeBytes : 0;
  const result = detector.detect(fileName, mimeType, sizeBytes);
  res.json(result);
});

export default router;
