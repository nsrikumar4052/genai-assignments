import { Router } from 'express';
import { TokenDetector } from '../../detectors/token.detector';

const router = Router();
const detector = new TokenDetector();

router.post('/', (req, res) => {
  const text = typeof req.body?.text === 'string' ? req.body.text : '';
  const result = detector.detect(text);
  res.json(result);
});

export default router;
