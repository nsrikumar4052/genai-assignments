import { Router, Request, Response, NextFunction } from 'express';
import { CiiDetector } from '../../detectors/cii.detector';
import { ModerationResponse } from '../../types';

const router = Router();
const detector = new CiiDetector();

router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text?: string; model?: string };

    if (!text) {
      res.status(400).json({ status: 'error', message: '`text` field is required' });
      return;
    }

    const result = detector.detect({ text, model });
    const sanitizedContent = result.triggered ? detector.mask(text) : text;
    const tokenEstimate = Math.ceil(text.length / 4);

    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    res.status(200).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
