import { Router } from 'express';
import { PiiDetector } from '../../detectors/pii.detector';

const router = Router();
const detector = new PiiDetector();

router.post('/', (req, res) => {
  const text = typeof req.body?.text === 'string' ? req.body.text : '';
  const result = detector.detect(text, []);
  res.json(result);
});

export default router;
