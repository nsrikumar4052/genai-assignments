import { Router, Request, Response, NextFunction } from 'express';
import { SecretDetector } from '../../detectors/secret.detector';
import { ModerationResponse } from '../../types';

const router = Router();
const detector = new SecretDetector();

router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text?: string; model?: string };

    if (!text) {
      res.status(400).json({ status: 'error', message: '`text` field is required' });
      return;
    }

    const result = detector.detect({ text, model });
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent: result.triggered ? undefined : text,
      originalContent: text,
      metadata: {
        tokenEstimate: Math.ceil(text.length / 4),
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    res.status(result.action === 'BLOCK' ? 422 : 200).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
