import { Router } from 'express';
import { InjectionDetector } from '../../detectors/injection.detector';

const router = Router();
const detector = new InjectionDetector();

router.post('/', (req, res) => {
  const text = typeof req.body?.text === 'string' ? req.body.text : '';
  const result = detector.detect(text);
  res.json(result);
});

export default router;
