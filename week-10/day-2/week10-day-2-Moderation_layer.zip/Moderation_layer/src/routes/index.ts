import { Router } from 'express';
import piiRoute from './detect/pii.route';
import secretRoute from './detect/secret.route';
import toxicRoute from './detect/toxic.route';
import injectionRoute from './detect/injection.route';
import ciiRoute from './detect/cii.route';
import fileRoute from './detect/file.route';
import tokenRoute from './detect/token.route';
import moderateRoute from './moderate.route';

const router = Router();

router.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'ai-shield' });
});

router.use('/detect/pii', piiRoute);
router.use('/detect/cii', ciiRoute);
router.use('/detect/secret', secretRoute);
router.use('/detect/toxic', toxicRoute);
router.use('/detect/injection', injectionRoute);
router.use('/detect/file', fileRoute);
router.use('/detect/token', tokenRoute);
router.use('/moderate', moderateRoute);

export default router;
