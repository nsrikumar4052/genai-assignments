import { DetectorResult, ModerationResponse } from '../types';
import { PiiDetector } from '../detectors/pii.detector';
import { SecretDetector } from '../detectors/secret.detector';
import { ToxicDetector } from '../detectors/toxic.detector';
import { InjectionDetector } from '../detectors/injection.detector';
import { CiiDetector } from '../detectors/cii.detector';
import { TokenDetector } from '../detectors/token.detector';

export class DecisionEngine {
  private piiDetector = new PiiDetector();
  private ciiDetector = new CiiDetector();
  private secretDetector = new SecretDetector();
  private toxicDetector = new ToxicDetector();
  private injectionDetector = new InjectionDetector();
  private tokenDetector = new TokenDetector();

  public moderate(text: string): ModerationResponse {
    const detectorResults: DetectorResult[] = [];

    detectorResults.push(this.piiDetector.detect(text, []));
    detectorResults.push(this.ciiDetector.detect({ text }));
    detectorResults.push(this.secretDetector.detect({ text }));
    detectorResults.push(this.toxicDetector.detect({ text }));
    detectorResults.push(this.injectionDetector.detect(text));
    detectorResults.push(this.tokenDetector.detect(text));

    const actions = detectorResults.map((result) => result.action);
    const action = actions.includes('BLOCK') ? 'BLOCK' : actions.includes('MASK') ? 'MASK' : 'ALLOW';

    const sanitizedContent = this.sanitize(text, detectorResults);

    return {
      status: 'success',
      action,
      detectorResults,
      sanitizedContent,
      originalContent: text,
      metadata: {
        tokenEstimate: Math.ceil(text.length / 4),
        processingTimeMs: 10,
        timestamp: new Date().toISOString()
      }
    };
  }

  private sanitize(text: string, detectorResults: DetectorResult[]): string {
    let sanitized = text;

    for (const result of detectorResults) {
      for (const finding of result.findings) {
        if (finding.masked) {
          sanitized = sanitized.replace(finding.value, finding.masked);
        }
      }
    }

    return sanitized;
  }
}
