import express from 'express';
import cors from 'cors';
import routes from './routes/index';
import { errorMiddleware } from './middleware/error.middleware';
import { requestLogger } from './middleware/request.logger';

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

app.use('/api', routes);

app.use(errorMiddleware);

export default app;
