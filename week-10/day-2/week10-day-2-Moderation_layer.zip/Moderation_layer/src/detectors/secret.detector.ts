import { BaseDetector } from './base.detector';
import { DetectorAction, Finding, ModerationRequest } from '../types';
import { loadRuleSets } from '../config/loader';

interface SecretConfig {
  enabled: boolean;
  defaultAction: string;
  rules: Array<{
    type: string;
    pattern: string;
    action: DetectorAction;
    enabled: boolean;
  }>;
}

export class SecretDetector extends BaseDetector {
  public readonly detectorName = 'secret';

  public detect(request: ModerationRequest): any {
    const config = loadRuleSets().secret as SecretConfig;
    if (!config?.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const findings: Finding[] = [];

    for (const rule of config.rules || []) {
      if (!rule.enabled) continue;

      const regex = new RegExp(rule.pattern, 'gi');
      let match: RegExpExecArray | null;

      while ((match = regex.exec(text)) !== null) {
        findings.push({
          type: rule.type,
          value: `${match[0].substring(0, 6)}****`,
          masked: '[SECRET_REDACTED]',
          position: { start: match.index, end: match.index + match[0].length }
        });
      }
    }

    const triggered = findings.length > 0;
    const action: DetectorAction = triggered ? 'BLOCK' : 'ALLOW';

    return this.buildResult(
      triggered,
      action,
      findings,
      triggered ? 'Request blocked: secrets detected in payload' : 'No secrets detected'
    );
  }
}
