import { BaseDetector } from './base.detector';
import { DetectorAction, Finding } from '../types';
import { loadRuleSets } from '../config/loader';

interface TokenConfig {
  model: string;
  maxTokens: number;
  charsPerToken: number;
  action: DetectorAction;
}

export class TokenDetector extends BaseDetector {
  public readonly detectorName = 'token';

  public detect(text: string): any {
    const config = loadRuleSets().token as TokenConfig;
    const findings: Finding[] = [];
    const charsPerToken = config?.charsPerToken || 4;
    const maxTokens = config?.maxTokens || 4000;
    const tokenEstimate = Math.ceil(text.length / charsPerToken);

    if (tokenEstimate > maxTokens) {
      findings.push({ type: 'token_limit', value: String(tokenEstimate), masked: '[TOKEN_REJECTED]' });
    }

    const action: DetectorAction = findings.length > 0 ? (config?.action || 'BLOCK') : 'ALLOW';
    return this.buildResult(findings.length > 0, action, findings, findings.length > 0 ? 'Token limit exceeded' : 'Token count acceptable');
  }
}
