import { BaseDetector } from './base.detector';
import { DetectorAction, Finding } from '../types';

export class PiiDetector extends BaseDetector {
  public readonly detectorName = 'pii';

  public detect(text: string, rules: Array<Record<string, unknown>>): any {
    const findings: Finding[] = [];
    const regex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const matches = text.matchAll(regex);

    for (const match of matches) {
      findings.push({
        type: 'email',
        value: match[0],
        masked: '[EMAIL_REDACTED]'
      });
    }

    const action: DetectorAction = findings.length > 0 ? 'MASK' : 'ALLOW';
    return this.buildResult(findings.length > 0, action, findings, findings.length > 0 ? 'PII detected' : 'No PII detected');
  }
}
