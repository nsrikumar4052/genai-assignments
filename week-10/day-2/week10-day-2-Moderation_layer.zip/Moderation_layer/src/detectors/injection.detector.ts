import { BaseDetector } from './base.detector';
import { DetectorAction, Finding } from '../types';
import { loadRuleSets } from '../config/loader';

interface InjectionConfig {
  enabled: boolean;
  defaultAction: DetectorAction;
  rules: Array<{
    type: string;
    patterns: string[];
    action: DetectorAction;
    enabled: boolean;
  }>;
}

export class InjectionDetector extends BaseDetector {
  public readonly detectorName = 'injection';

  public detect(text: string): any {
    const config = loadRuleSets().injection as InjectionConfig;
    if (!config?.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const findings: Finding[] = [];
    const lower = text.toLowerCase();

    for (const rule of config.rules || []) {
      if (!rule.enabled) continue;

      for (const pattern of rule.patterns || []) {
        if (lower.includes(pattern.toLowerCase())) {
          findings.push({
            type: rule.type,
            value: pattern,
            masked: '[INJECTION_REDACTED]'
          });
        }
      }
    }

    const triggered = findings.length > 0;
    const action: DetectorAction = triggered ? (config.defaultAction || 'BLOCK') : 'ALLOW';

    return this.buildResult(
      triggered,
      action,
      findings,
      triggered ? 'Injection pattern detected' : 'No injection patterns detected'
    );
  }
}
