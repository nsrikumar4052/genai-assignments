import { BaseDetector } from './base.detector';
import { DetectorAction, Finding, ModerationRequest } from '../types';
import { loadRuleSets } from '../config/loader';

interface ToxicCategory {
  category?: string;
  severity: 'low' | 'medium' | 'high';
  keywords: string[];
  action: DetectorAction;
  enabled: boolean;
}

interface ToxicConfig {
  enabled: boolean;
  defaultAction: string;
  categories?: ToxicCategory[];
  rules?: ToxicCategory[];
  blockOnSeverity?: Array<'low' | 'medium' | 'high'>;
}

export class ToxicDetector extends BaseDetector {
  public readonly detectorName = 'toxic';

  public detect(request: ModerationRequest): any {
    const config = loadRuleSets().toxic as ToxicConfig;
    if (!config?.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text?.toLowerCase() || '';
    const findings: Finding[] = [];
    const categories = config.categories || config.rules || [];
    const blockingSeverities = new Set(config.blockOnSeverity || ['high', 'medium']);

    for (const category of categories) {
      if (!category.enabled) continue;

      for (const keyword of category.keywords) {
        if (text.includes(keyword.toLowerCase())) {
          findings.push({
            type: category.category || 'toxic',
            value: keyword,
            severity: category.severity,
            masked: '[TOXIC_REDACTED]'
          });
        }
      }
    }

    if (findings.length === 0) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const shouldBlock = findings.some((finding) => blockingSeverities.has(finding.severity || 'low'));
    const action: DetectorAction = shouldBlock ? 'BLOCK' : 'ALLOW';

    return this.buildResult(
      true,
      action,
      findings,
      shouldBlock ? 'Request blocked: toxic content detected' : 'Low severity toxic content — allowed'
    );
  }
}
