import { BaseDetector } from './base.detector';
import { DetectorAction, Finding } from '../types';
import { loadRuleSets } from '../config/loader';

interface FileConfig {
  allowedExtensions: string[];
  allowedMimeTypes: string[];
  maxFileSizeBytes: number;
  action: DetectorAction;
}

export class FileDetector extends BaseDetector {
  public readonly detectorName = 'file';

  public detect(fileName: string, mimeType: string, sizeBytes: number): any {
    const config = loadRuleSets().file as FileConfig;
    const findings: Finding[] = [];

    const allowedExtensions = config?.allowedExtensions || [];
    const allowedMimeTypes = config?.allowedMimeTypes || [];
    const maxFileSizeBytes = config?.maxFileSizeBytes || 0;

    const ext = fileName.toLowerCase().slice(fileName.lastIndexOf('.'));
    if (!allowedExtensions.includes(ext)) {
      findings.push({ type: 'extension', value: ext, masked: '[FILE_REJECTED]' });
    }

    if (!allowedMimeTypes.includes(mimeType)) {
      findings.push({ type: 'mime_type', value: mimeType, masked: '[FILE_REJECTED]' });
    }

    if (sizeBytes > maxFileSizeBytes) {
      findings.push({ type: 'size', value: String(sizeBytes), masked: '[FILE_REJECTED]' });
    }

    const action: DetectorAction = findings.length > 0 ? (config?.action || 'BLOCK') : 'ALLOW';
    return this.buildResult(findings.length > 0, action, findings, findings.length > 0 ? 'File validation failed' : 'File validation passed');
  }
}
