import { BaseDetector } from './base.detector';
import { CiiRule, DetectorAction, Finding, ModerationRequest } from '../types';
import { loadRuleSets } from '../config/loader';

interface CiiConfig {
  enabled: boolean;
  defaultAction: string;
  rules: CiiRule[];
}

export class CiiDetector extends BaseDetector {
  public readonly detectorName = 'cii';

  public detect(request: ModerationRequest): any {
    const config = loadRuleSets().cii as CiiConfig;
    if (!config?.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const findings: Finding[] = [];

    for (const rule of config.rules || []) {
      if (!rule.enabled) continue;

      if (rule.keywords) {
        for (const keyword of rule.keywords) {
          if (text.toLowerCase().includes(keyword.toLowerCase())) {
            findings.push({
              type: rule.type,
              value: keyword,
              masked: `[${rule.type.toUpperCase()}_REDACTED]`
            });
          }
        }
      }

      if (rule.pattern) {
        const regex = new RegExp(rule.pattern, 'gi');
        let match: RegExpExecArray | null;

        while ((match = regex.exec(text)) !== null) {
          findings.push({
            type: rule.type,
            value: match[0],
            masked: `[${rule.type.toUpperCase()}_REDACTED]`,
            position: { start: match.index, end: match.index + match[0].length }
          });
        }
      }
    }

    const triggered = findings.length > 0;
    const action: DetectorAction = triggered ? 'MASK' : 'ALLOW';

    return this.buildResult(
      triggered,
      action,
      findings,
      triggered ? 'Confidential information detected' : 'No confidential information detected'
    );
  }

  public mask(text: string): string {
    const config = loadRuleSets().cii as CiiConfig;
    let masked = text;

    for (const rule of config.rules || []) {
      if (!rule.enabled) continue;

      const replacement = `[${rule.type.toUpperCase()}_REDACTED]`;

      if (rule.keywords) {
        for (const keyword of rule.keywords) {
          masked = masked.replace(new RegExp(keyword, 'gi'), replacement);
        }
      }

      if (rule.pattern) {
        masked = masked.replace(new RegExp(rule.pattern, 'gi'), replacement);
      }
    }

    return masked;
  }
}
