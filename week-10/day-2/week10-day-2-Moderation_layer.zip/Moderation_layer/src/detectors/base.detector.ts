import { DetectorAction, DetectorResult, Finding } from '../types';

export abstract class BaseDetector {
  public abstract readonly detectorName: string;

  protected buildResult(triggered: boolean, action: DetectorAction, findings: Finding[], message?: string): DetectorResult {
    return {
      detector: this.detectorName,
      triggered,
      action,
      findings,
      message
    };
  }
}
