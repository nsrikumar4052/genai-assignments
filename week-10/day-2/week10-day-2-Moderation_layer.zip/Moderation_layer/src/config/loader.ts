import fs from 'fs';
import path from 'path';

const rulesDir = path.resolve(__dirname, '../../rules');

export interface RuleSetMap {
  pii: unknown;
  cii: unknown;
  secret: unknown;
  toxic: unknown;
  injection: unknown;
  file: unknown;
  token: unknown;
}

const ruleFiles: Record<keyof RuleSetMap, string> = {
  pii: 'pii-rules.json',
  cii: 'cii-rules.json',
  secret: 'secret-rules.json',
  toxic: 'toxic-rules.json',
  injection: 'injection-rules.json',
  file: 'file-rules.json',
  token: 'token-rules.json'
};

const cache = new Map<keyof RuleSetMap, { mtimeMs: number; data: unknown }>();

export const loadRuleSets = (): RuleSetMap => {
  const loaded = {} as RuleSetMap;

  for (const [key, fileName] of Object.entries(ruleFiles) as Array<[keyof RuleSetMap, string]>) {
    const fullPath = path.join(rulesDir, fileName);
    const stats = fs.statSync(fullPath);
    const cached = cache.get(key);

    if (cached && cached.mtimeMs === stats.mtimeMs) {
      loaded[key] = cached.data;
      continue;
    }

    const data = JSON.parse(fs.readFileSync(fullPath, 'utf8'));
    cache.set(key, { mtimeMs: stats.mtimeMs, data });
    loaded[key] = data;
  }

  return loaded;
};
