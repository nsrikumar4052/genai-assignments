import { NextFunction, Request, Response } from 'express';
import { logger } from '../utils/logger';

export const errorMiddleware = (
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction
) => {
  const message = err instanceof Error ? err.message : 'Internal server error';

  logger.error('request failed', {
    method: req.method,
    path: req.originalUrl,
    error: message,
    stack: err instanceof Error ? err.stack : undefined
  });

  res.status(500).json({
    status: 'error',
    action: 'BLOCK',
    detectorResults: [],
    message,
    metadata: {
      tokenEstimate: 0,
      processingTimeMs: 0,
      timestamp: new Date().toISOString()
    }
  });
};
