import { FileDetector } from '../../src/detectors/file.detector';

describe('FileDetector', () => {
  let detector: FileDetector;

  beforeEach(() => {
    detector = new FileDetector();
  });

  describe('detect', () => {
    it('should allow valid file types', () => {
      const result = detector.detect('document.pdf', 'application/pdf', 1024000);
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should block executable files', () => {
      const result = detector.detect('malware.exe', 'application/x-msdownload', 1024000);
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.some((f) => f.type === 'extension')).toBe(true);
    });

    it('should block files with invalid MIME type', () => {
      const result = detector.detect('document.pdf', 'application/x-dangerous', 1024000);
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.some((f) => f.type === 'mime_type')).toBe(true);
    });

    it('should block oversized files', () => {
      const result = detector.detect('large.txt', 'text/plain', 10000000);
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.some((f) => f.type === 'size')).toBe(true);
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('file');
    });

    it('should be case-insensitive for extensions', () => {
      const result1 = detector.detect('file.PDF', 'application/pdf', 1024000);
      const result2 = detector.detect('file.pdf', 'application/pdf', 1024000);
      expect(result1.triggered).toBe(result2.triggered);
    });

    it('should detect multiple violations in one file', () => {
      const result = detector.detect('malware.exe', 'application/x-msdownload', 10000000);
      expect(result.findings.length).toBe(3);
    });

    it('should return proper message when file is valid', () => {
      const result = detector.detect('document.txt', 'text/plain', 100000);
      expect(result.message).toBe('File validation passed');
    });

    it('should return proper message when file is invalid', () => {
      const result = detector.detect('malware.exe', 'application/x-msdownload', 1024000);
      expect(result.message).toBe('File validation failed');
    });
  });
});
