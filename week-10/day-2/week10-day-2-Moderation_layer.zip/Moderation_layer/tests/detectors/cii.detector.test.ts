import { CiiDetector } from '../../src/detectors/cii.detector';

describe('CiiDetector', () => {
  let detector: CiiDetector;

  beforeEach(() => {
    detector = new CiiDetector();
  });

  describe('detect', () => {
    it('should detect codenames in text', () => {
      const result = detector.detect({ text: 'Project project-phoenix is our internal codename' });
      expect(result.detector).toBe('cii');
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('MASK');
    });

    it('should detect internal URLs', () => {
      const result = detector.detect({ text: 'Check the roadmap at https://intranet.testleaf.com' });
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('MASK');
    });

    it('should return ALLOW when no CII is detected', () => {
      const result = detector.detect({ text: 'This is public information' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
      expect(result.findings.length).toBe(0);
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('cii');
    });

    it('should handle empty text', () => {
      const result = detector.detect({ text: '' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should handle undefined text', () => {
      const result = detector.detect({ text: undefined });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });
  });
});
