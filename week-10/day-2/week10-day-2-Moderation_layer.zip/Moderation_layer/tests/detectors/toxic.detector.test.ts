import { ToxicDetector } from '../../src/detectors/toxic.detector';

describe('ToxicDetector', () => {
  let detector: ToxicDetector;

  beforeEach(() => {
    detector = new ToxicDetector();
  });

  describe('detect', () => {
    it('should detect toxic keywords in text', () => {
      const result = detector.detect({ text: 'I will kill this project' });
      expect(result.detector).toBe('toxic');
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.length).toBeGreaterThan(0);
    });

    it('should detect abusive language', () => {
      const result = detector.detect({ text: 'You are stupid for this' });
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
    });

    it('should detect multiple toxic keywords', () => {
      const result = detector.detect({ text: 'This is stupid and I hate it' });
      expect(result.triggered).toBe(true);
      expect(result.findings.length).toBeGreaterThan(0);
    });

    it('should return ALLOW when no toxic content is detected', () => {
      const result = detector.detect({ text: 'This is a nice and friendly message' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('toxic');
    });

    it('should be case-insensitive', () => {
      const result1 = detector.detect({ text: 'Kill' });
      const result2 = detector.detect({ text: 'KILL' });
      const result3 = detector.detect({ text: 'kill' });
      expect(result1.triggered).toBe(result2.triggered);
      expect(result2.triggered).toBe(result3.triggered);
    });

    it('should handle empty text', () => {
      const result = detector.detect({ text: '' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });
  });
});
