import { SecretDetector } from '../../src/detectors/secret.detector';

describe('SecretDetector', () => {
  let detector: SecretDetector;

  beforeEach(() => {
    detector = new SecretDetector();
  });

  describe('detect', () => {
    it('should detect Google API keys', () => {
      const result = detector.detect({ text: 'API_KEY=AIzaSyDVitjUGXWDl_-pPEu-OkbKEJzLfM0c3tI' });
      expect(result.detector).toBe('secret');
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.length).toBeGreaterThan(0);
    });

    it('should block when secrets are detected', () => {
      const result = detector.detect({ text: 'Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=' });
      expect(result.action).toBe('BLOCK');
      expect(result.message).toContain('Request blocked');
    });

    it('should return ALLOW when no secrets are detected', () => {
      const result = detector.detect({ text: 'This is a normal message without secrets' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('secret');
    });

    it('should handle empty text', () => {
      const result = detector.detect({ text: '' });
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should return proper message when no secrets detected', () => {
      const result = detector.detect({ text: 'safe content' });
      expect(result.message).toBe('No secrets detected');
    });
  });
});
