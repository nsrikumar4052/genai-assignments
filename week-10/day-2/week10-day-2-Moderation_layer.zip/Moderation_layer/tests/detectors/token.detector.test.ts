import { TokenDetector } from '../../src/detectors/token.detector';

describe('TokenDetector', () => {
  let detector: TokenDetector;

  beforeEach(() => {
    detector = new TokenDetector();
  });

  describe('detect', () => {
    it('should allow text within token limit', () => {
      const result = detector.detect('short message');
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should block text exceeding token limit', () => {
      const longText = 'a'.repeat(20000);
      const result = detector.detect(longText);
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('BLOCK');
      expect(result.findings.some((f) => f.type === 'token_limit')).toBe(true);
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('token');
    });

    it('should estimate tokens correctly', () => {
      const text = 'a'.repeat(400); // 100 tokens at 4 chars per token
      const result = detector.detect(text);
      const finding = result.findings.find((f) => f.type === 'token_limit');
      if (finding) {
        expect(parseInt(finding.value)).toBeCloseTo(100, -1);
      }
    });

    it('should handle empty text', () => {
      const result = detector.detect('');
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
    });

    it('should return proper message when token limit is exceeded', () => {
      const longText = 'a'.repeat(20000);
      const result = detector.detect(longText);
      expect(result.message).toBe('Token limit exceeded');
    });

    it('should return proper message when token limit is acceptable', () => {
      const result = detector.detect('short text');
      expect(result.message).toBe('Token count acceptable');
    });

    it('should calculate tokens based on text length', () => {
      const text = 'This is a test'; // ~3-4 tokens
      const result = detector.detect(text);
      expect(result.triggered).toBe(false); // Should be well within limit
    });
  });
});
