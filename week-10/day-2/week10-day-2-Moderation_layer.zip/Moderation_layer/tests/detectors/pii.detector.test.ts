import { PiiDetector } from '../../src/detectors/pii.detector';

describe('PiiDetector', () => {
  let detector: PiiDetector;

  beforeEach(() => {
    detector = new PiiDetector();
  });

  describe('detect', () => {
    it('should detect email addresses', () => {
      const result = detector.detect('Contact john@example.com for more info', []);
      expect(result.triggered).toBe(true);
      expect(result.action).toBe('MASK');
      expect(result.findings.length).toBeGreaterThan(0);
      expect(result.findings[0].type).toBe('email');
      expect(result.findings[0].value).toBe('john@example.com');
      expect(result.findings[0].masked).toBe('[EMAIL_REDACTED]');
    });

    it('should detect multiple email addresses', () => {
      const result = detector.detect('Email alice@test.com or bob@test.com', []);
      expect(result.triggered).toBe(true);
      expect(result.findings.length).toBe(2);
    });

    it('should return ALLOW when no PII is detected', () => {
      const result = detector.detect('Hello world, this is a normal message', []);
      expect(result.triggered).toBe(false);
      expect(result.action).toBe('ALLOW');
      expect(result.findings.length).toBe(0);
    });

    it('should have correct detector name', () => {
      expect(detector.detectorName).toBe('pii');
    });

    it('should return proper message when PII is detected', () => {
      const result = detector.detect('user@domain.com', []);
      expect(result.message).toBe('PII detected');
    });

    it('should return proper message when no PII is detected', () => {
      const result = detector.detect('safe text', []);
      expect(result.message).toBe('No PII detected');
    });
  });
});
